package com.penelope.banchanggo;

import android.app.Application;

import dagger.hilt.android.HiltAndroidApp;

@HiltAndroidApp
public class BanchanggoApplication extends Application {
}
